const year = '2017-2018'
const semester = '1'
const userId = '1001'

export default{
  year,
  semester,
  userId
}