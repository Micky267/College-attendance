<template>
  <div class="cur-nav">
  </div>
</template>

<script>
export default {
  name: "curNav"
};
</script>

<style scoped>
</style>
