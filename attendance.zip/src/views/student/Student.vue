<template>
  <div class="student">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: "student"
};
</script>

<style scoped>
</style>
