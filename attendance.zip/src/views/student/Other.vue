<template>
  <div class="other">
    待开发。。。
  </div>
</template>

<script>
export default {
};
</script>

<style scoped>
</style>
