<template>
  <div class="teacher">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: "teacher"
};
</script>

<style scoped>
</style>
