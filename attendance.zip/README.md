<<<<<<< HEAD
# attendance-admin

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your unit tests
```
npm run test:unit
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
=======
# College-attendance
基于web的高校考勤管理系统
>>>>>>> baf8ff54adc92a7b42a38605e013915a8cc6ef50
